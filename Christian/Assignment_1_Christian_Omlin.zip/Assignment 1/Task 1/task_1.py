print('Hello, World!\n')
