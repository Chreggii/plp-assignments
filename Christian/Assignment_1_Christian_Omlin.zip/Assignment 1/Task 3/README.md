In order to test Task 3 run the `main.py` file.
