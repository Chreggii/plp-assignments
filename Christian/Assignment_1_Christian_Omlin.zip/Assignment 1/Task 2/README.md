In order to test Task 2 run the `main.py` file.
