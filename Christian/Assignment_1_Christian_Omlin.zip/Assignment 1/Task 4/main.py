
from console_interceptor import ConsoleInterceptor

if __name__ == "__main__":

    ConsoleInterceptor.process_console_input()
