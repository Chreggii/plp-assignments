In order to test Task 4 run the `main.py` file.
